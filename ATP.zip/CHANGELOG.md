# 0.8.1
  * @angular/cli v7.1
  * update footer message

# 0.8.0 Angular 7
  * @angular v7.1
  * @angular/cli v7
  * x-editable
  * remove ngx-popover dependency

# 0.7.0 Angular 6 and Ngrx
  * angular v6
  * @angular/cli v6
  * rxjs v6
  * ngx-bootstrap v3
  * @ngrx/{store,effects,entity,store-devtools,schematics} v6
  * @swimlane/ngx-datatable v13

# 0.6.2  
  * angular@5.2.6
  * angular-cli@1.7.1
  * remove jquery.color dependency

# 0.6.1
  * all <sa-widget> components are changed to <div sa-widget> directive
  * angular@5.0.5
  * angular-cli@1.5.5

# 0.6.0
  * angular@5.0.3
  * angular-cli@1.5.4
  * jquery@3.2.1
  * fix widgets postion save

# 0.5.0
  * ngx-datatables demo
  * angular@4.3.2
  * angular-cli@1.2.6
  
# 0.4.5
  * AOT support
  * update ngx-bootstrap@2, dygraphs@2.0.0 and other plugins

# 0.4.4 
  * update ngx-bootstrap, datatables-responsive, default include polyfills

# 0.4.3 
  * update ng2-bootstrap, ngx-popover, @angular-redux 

# 0.4.2
  * freeze dependencies

# 0.4.1
  * remove flexbox layout

# 0.4.0
  * angular@4 support 
  * angular-cli@1 

# 0.3.1
  * restore angular-cli support
  
# 0.2.1
  * hot module replacement
  * router animations

# 0.2.0
  * switch to custom webpack build flow 
  * drop angular-cli
  
# 0.1.1 
  * making bird-eye widget with d3js  
  
# 0.1.0
  * migrate with angular-cli from SystemJs to webpack 2
  * lazy routes
  

# 0.0.1
  * angular-cli support
