import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-profile',
  templateUrl: './profile.component.html',
})
export class ProfileComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
