import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'sa-bootstrap-validation',
  templateUrl: './bootstrap-validation.component.html',
})
export class BootstrapValidationComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
