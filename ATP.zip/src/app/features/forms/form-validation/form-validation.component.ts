import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-form-validation',
  templateUrl: './form-validation.component.html',
})
export class FormValidationComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
