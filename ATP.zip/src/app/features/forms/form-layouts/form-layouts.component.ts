import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'sa-form-layouts',
  templateUrl: './form-layouts.component.html',
})
export class FormLayoutsComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
