import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'atp-research',
    templateUrl: './atp-research.component.html',
    styleUrls: ['./atp-research.component.scss'],
})
export class AtpResearchComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
