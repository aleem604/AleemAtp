import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-highchart-tables',
  templateUrl: './highchart-tables.component.html',
})
export class HighchartTablesComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
