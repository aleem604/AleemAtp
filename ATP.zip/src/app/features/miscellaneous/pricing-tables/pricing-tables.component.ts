import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing-tables',
  templateUrl: './pricing-tables.component.html',
})
export class PricingTablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
