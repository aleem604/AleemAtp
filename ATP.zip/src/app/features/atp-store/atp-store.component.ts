import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'atp-store',
    templateUrl: './atp-store.component.html',
    styleUrls: ['./atp-store.component.scss'],
})
export class AtpStoreComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
