import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'atp-funding',
    templateUrl: './atp-funding.component.html',
    styleUrls: ['./atp-funding.component.scss'],
})
export class AtpFundingComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
