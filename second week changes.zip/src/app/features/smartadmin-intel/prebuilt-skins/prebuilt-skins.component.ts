import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-prebuilt-skins',
  templateUrl: './prebuilt-skins.component.html',
})
export class PrebuiltSkinsComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
