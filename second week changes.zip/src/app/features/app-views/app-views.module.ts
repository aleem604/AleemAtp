import {NgModule} from "@angular/core";

import {routing} from "./app-views.routing";

@NgModule({
  declarations: [

  ],
  imports: [
    routing,

  ],
  entryComponents: []
})
export class AppViewsModule {
}
