import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-form-elements',
  templateUrl: './form-elements.component.html',
})
export class FormElementsComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
