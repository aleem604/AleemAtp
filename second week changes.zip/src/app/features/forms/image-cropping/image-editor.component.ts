import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-image-editor',
  templateUrl: './image-editor.component.html',
})
export class ImageEditorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
}
