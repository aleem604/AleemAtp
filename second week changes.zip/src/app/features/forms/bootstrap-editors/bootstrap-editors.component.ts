import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootstrap-editors',
  templateUrl: './bootstrap-editors.component.html',
})
export class BootstrapEditorsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
