import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sa-normal-tables',
  templateUrl: './normal-tables.component.html',

})
export class NormalTablesComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
