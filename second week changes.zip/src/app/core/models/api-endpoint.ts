export  class ApiEndpoint {
	public  static Atp_Endpoint = 'https://localhost:44301/api/v1';
}
