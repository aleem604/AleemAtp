﻿export interface OrganizationModel {
    id: number;
    avatar: any;
    name: string;
    following: boolean;
}